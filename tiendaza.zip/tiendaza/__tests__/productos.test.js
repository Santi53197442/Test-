const filtrarProductos = require('../js/productos');

// Escribir los tests debajo

